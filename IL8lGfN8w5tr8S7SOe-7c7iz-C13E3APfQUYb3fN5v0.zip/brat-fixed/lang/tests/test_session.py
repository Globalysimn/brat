"""Inferred channel protocols: the shape of a pipe, and whether it can finish.

Every case runs through both checkers (`cli.py check` and `brat-cxx check`) and
the diagnostics must match byte for byte. A refused program is also built and
run on both backends to prove the refusal is not hiding a working program.
"""
import _scratch
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.abspath(os.path.join(HERE, "..", "engine"))
CXX = os.path.abspath(os.path.join(HERE, "..", "cxx", "bin", "brat-cxx"))
CLI = os.path.join(ENGINE, "cli.py")
TMP = _scratch.mkdtemp(prefix="brat-session-")

HAVE_CXX = os.path.exists(CXX)

CASES = [
    # name, source, list of substrings that must appear in the diagnostics
    ("balanced", '''fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  print(ch.recv())
  return 0
}
''', []),
    ("queue_holds_the_rest", '''fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  ch.send(2)
  print(ch.recv())
  return 0
}
''', []),
    ("send_blocks", '''fn main() -> i64 {
  let ch = chan(1)
  ch.send(1)
  ch.send(2)
  ch.send(3)
  print(ch.recv())
  return 0
}
''', ["`ch`: 3 value(s) sent into a queue of 1 and only 1 received"]),
    ("recv_waits", '''fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  print(ch.recv())
  print(ch.recv())
  return 0
}
''', ["`ch`: 2 receive(s) but only 1 send(s) — `recv` waits forever"]),
    ("helper_hides_the_receive", '''fn drain(ch) -> i64 {
  return ch.recv()
}
fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  ch.send(2)
  return drain(ch)
}
''', []),
    ("loop_is_not_counted", '''fn main() -> i64 {
  let ch = chan(8)
  for i in 0..3 {
    ch.send(i)
  }
  let mut t = 0
  for i in 0..3 {
    t = t + ch.recv()
  }
  return t
}
''', []),
    ("branch_is_not_counted", '''fn main() -> i64 {
  let ch = chan(2)
  if true {
    ch.send(1)
  } else {
    ch.send(2)
  }
  for i in 0..1 {
    print(ch.recv())
  }
  return 0
}
''', []),
    ("two_channels", '''fn main() -> i64 {
  let a = chan(1)
  let b = chan(1)
  a.send(1)
  b.send(2)
  b.send(3)
  b.send(4)
  print(a.recv())
  print(b.recv())
  return 0
}
''', ["`b`: 3 value(s) sent into a queue of 1"]),
    ("close_is_not_the_end", '''fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  ch.close()
  print(ch.recv())
  print(ch.recv())
  return 0
}
''', []),
    ("queue_full_at_the_second_send", '''fn main() -> i64 {
  let ch = chan(1)
  ch.send(1)
  ch.send(2)
  print(ch.recv())
  return 0
}
''', ["`ch`: 2 value(s) sent into a queue of 1 and only 1 received"]),
    ("three_into_two", '''fn main() -> i64 {
  let ch = chan(2)
  ch.send(1)
  ch.send(2)
  ch.send(3)
  print(ch.recv())
  return 0
}
''', ["`ch`: 3 value(s) sent into a queue of 2 and only 1 received"]),
    ("drain_keeps_the_prefix_short", '''fn main() -> i64 {
  let ch = chan(1)
  ch.send(1)
  print(ch.recv())
  ch.send(2)
  print(ch.recv())
  return 0
}
''', []),
    ("spawn_send_balanced", '''fn main() -> i64 {
  let ch = chan(2)
  spawn {
    ch.send(7)
  }
  join_all()
  return ch.recv()
}
''', []),
]


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=300, **kw)


def check(path):
    out = run([sys.executable, CLI, "check", "--py", path])
    return out.returncode, out.stdout + out.stderr


def main():
    failures = 0
    for name, src, wants in CASES:
        path = os.path.join(TMP, name + ".brat")
        with open(path, "w", encoding="utf-8") as f:
            f.write(src)
        rc, text = check(path)
        for want in wants:
            if want not in text:
                print("FAIL %s: missing %r" % (name, want))
                print(text)
                failures += 1
        if wants and rc == 0:
            print("FAIL %s: should have been refused" % name)
            failures += 1
        if not wants and rc != 0:
            print("FAIL %s: refused a program that finishes" % name)
            print(text)
            failures += 1
        if HAVE_CXX:
            c = run([CXX, "check", path])
            py = "\n".join(l for l in text.splitlines() if "type error" not in l)
            cx = "\n".join(l for l in (c.stdout + c.stderr).splitlines() if "type error" not in l)
            if py.strip() != cx.strip():
                print("FAIL %s: checkers disagree\n--- python\n%s\n--- cxx\n%s" % (name, py, cx))
                failures += 1

    proto = run([sys.executable, CLI, "check", "--proto", os.path.join(TMP, "balanced.brat")])
    if "balanced" not in proto.stdout:
        print("FAIL --proto did not report a balanced pipe:\n" + proto.stdout)
        failures += 1
    proto = run([sys.executable, CLI, "check", "--proto",
                 os.path.join(TMP, "send_blocks.brat")])
    if "DEADLOCK" not in proto.stdout:
        print("FAIL --proto did not flag a deadlock:\n" + proto.stdout)
        failures += 1

    if failures:
        raise SystemExit("SESSION FAILED (%d)" % failures)
    print("SESSION ALL GREEN (%d cases%s)" % (len(CASES), ", both checkers" if HAVE_CXX else ""))


if __name__ == "__main__":
    main()
